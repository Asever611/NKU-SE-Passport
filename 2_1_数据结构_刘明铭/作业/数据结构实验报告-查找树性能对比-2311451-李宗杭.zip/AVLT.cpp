#include"AVLT.h"
#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<cmath>
using namespace std;

AVLnode::AVLnode(int x = -1) : lchild(NULL), rchild(NULL), data(x) {}

AVL::AVL() : root(NULL), count(0) {}

AVL::AVL(AVLnode* x) : root(x), count(1) {}

int AVL::height(AVLnode* x)
{
	if (!x)
	{
		return 0;
	}
	return max(height(x->lchild), height(x->rchild)) + 1;
}

AVLnode* AVL::Min(AVLnode* x)
{
	AVLnode* curr = x;
	while (curr->lchild)
	{
		curr = curr->lchild;
	}
	return curr;
}

AVLnode* AVL::search(int x, AVLnode* r)
{
	AVLnode* curr = r;
	while (curr)
	{
		if (x < curr->data)
		{
			curr = curr->lchild;
		}
		else if (x > curr->data)
		{
			curr = curr->rchild;
		}
		else
		{
			return curr;
		}
	}
	return curr;
}

AVLnode* AVL::L(AVLnode* x)
{
	AVLnode* t = x->rchild;
	x->rchild = t->lchild;
	t->lchild = x;
	return t;
}

AVLnode* AVL::R(AVLnode* x)
{
	AVLnode* t = x->lchild;
	x->lchild = t->rchild;
	t->rchild = x;
	return t;
}

AVLnode* AVL::Insert(int x, AVLnode*& r)
{
	if (r == nullptr)
	{
		r = new AVLnode(x);
		count++;
		return r;
	}

	if (x < r->data)
	{
		r->lchild = Insert(x, r->lchild);
	}
	else if (x > r->data)
	{
		r->rchild = Insert(x, r->rchild);
	}

	return Balance(r);
}

AVLnode* AVL::Balance(AVLnode*& x)
{
	if (x == nullptr)
	{
		return x;
	}

	int balanceFactor = height(x->lchild) - height(x->rchild);

	if (balanceFactor > 1)  // ����������������
	{
		if (height(x->lchild->rchild) > height(x->lchild->lchild)) // LR case
		{
			x->lchild = L(x->lchild); // ������
		}
		x = R(x); // ������
	}
	else if (balanceFactor < -1) // ����������������
	{
		if (height(x->rchild->lchild) > height(x->rchild->rchild)) // RL case
		{
			x->rchild = R(x->rchild); // ������
		}
		x = L(x); // ������
	}

	return x;
}

void AVL::Delete(int x, AVLnode*& r)
{
	if (x < r->data)
	{
		Delete(x, r->lchild);
	}
	else if (x > r->data)
	{
		Delete(x, r->rchild);
	}
	else
	{
		if (!r->lchild || !r->rchild)
		{
			AVLnode* t = r->lchild ? r->lchild : r->rchild;
			if (t)
			{
				*r = *t;
			}
			else
			{
				t = r;
				r = nullptr;
			}
			delete t;
			count--;
		}
		else
		{
			AVLnode* t = Min(r->rchild);
			r->data = t->data;
			Delete(t->data, r->rchild);
		}
	}

	if (r)
	{
		r = Balance(r);
	}
}
void AVL::bfs()
{
	int judge = 1;//�Ƿ���ȫ
	AVLnode* curr;
	queue<AVLnode*> a;
	vector<int> b(20, -1);//�洢����������
	int i = 0;
	a.push(root);
	int k = 0;//�Ƿ���ֹ��պ���
	while (!a.empty())
	{
		curr = a.front();
		a.pop();
		b[i++] = curr->data;
		if (curr->lchild)
		{
			a.push(curr->lchild);
			if (k == 1)
			{
				judge = 0;
			}
		}
		else
		{
			k = 1;
		}
		if (curr->rchild)
		{
			a.push(curr->rchild);
			if (k == 1)
			{
				judge = 0;
			}
		}
		else
		{
			k = 1;
		}
	}
	for (int j = 0; j < i - 1; j++)
	{
		cout << b[j] << " ";
	}
	cout << b[i - 1] << endl;
	if (judge) cout << "Yes";
	else cout << "No";
}

void AVL::preorder(AVLnode* x)
{
	if (x == NULL)
	{
		return;
	}
	cout << x->data << " ";
	preorder(x->lchild);
	preorder(x->rchild);
}

void AVL::inorder(AVLnode* x)
{
	if (x == NULL)
	{
		return;
	}
	inorder(x->lchild);
	cout << x->data << " ";
	inorder(x->rchild);
}

void AVL::order(int x)
{
	if (x == 0)
	{
		bfs();
	}
	if (x == 1)
	{
		preorder(root);
	}
	if (x == 2)
	{
		inorder(root);
	}
}
