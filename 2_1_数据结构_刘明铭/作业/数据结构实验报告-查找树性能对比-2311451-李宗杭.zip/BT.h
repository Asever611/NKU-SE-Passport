#pragma once

// BTreeNode�ࣺ��ʾB���Ľ��ṹ
class BTreeNode {
    int* keys;
    int t;
    BTreeNode** C;
    int n;
    bool leaf;

public:
    BTreeNode(int _t, bool _leaf);

    void traverse();

    int findKey(int k);
    void insertNonFull(int k);
    void splitChild(int i, BTreeNode* y);
    void deletion(int k);
    void removeFromLeaf(int idx);
    void removeFromNonLeaf(int idx);
    int getPredecessor(int idx);
    int getSuccessor(int idx);
    void fill(int idx);
    void borrowFromPrev(int idx);
    void borrowFromNext(int idx);
    void merge(int idx);
    BTreeNode* search(int k);
    friend class BTree;
};

//  BTree�ࣺ��ʾ����B���ṹ���ṩB���������ܣ����ҡ����롢ɾ��
class BTree {
    BTreeNode* root;
    int t;

public:
    BTree(int _t);

    void traverse(); 

    void insertion(int k);

    void deletion(int k);

    bool search(int k);
};

