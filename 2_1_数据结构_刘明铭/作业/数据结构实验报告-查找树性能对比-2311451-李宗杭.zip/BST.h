#pragma once

class BST_node
{
public:
	BST_node* lchild;
	BST_node* rchild;
	int data;
	BST_node(int x);
};

class BST {
public:
	BST_node* root;
	int count; // Ԫ�ظ���
	BST();
	BST(BST_node* x);

	int height(BST_node* x);
	void Insert(int x);
	void Delete(int x);
	void bfs();
	void order(int x);
	void preorder(BST_node* x);
	void inorder(BST_node* x);
	BST_node* Min(BST_node* x);
	BST_node* search(int x, BST_node* r);
};

