#include"BST.h"
#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<cmath>
#include<stack>
using namespace std;

BST_node::BST_node(int x = -1) : lchild(NULL), rchild(NULL), data(x) {}

BST::BST() : root(NULL), count(0) {}

BST::BST(BST_node* x) : root(x), count(1) {}

int BST::height(BST_node* x)
{
	if (!x)
	{
		return 0;
	}
	return max(height(x->lchild), height(x->rchild)) + 1;
}

BST_node* BST::Min(BST_node* x)
{
	BST_node* curr = x;
	while (curr->lchild)
	{
		curr = curr->lchild;
	}
	return curr;
}

BST_node* BST::search(int x, BST_node* r)
{
	BST_node* curr = r;
	while (curr)
	{
		if (x < curr->data)
		{
			curr = curr->lchild;
		}
		else if (x > curr->data)
		{
			curr = curr->rchild;
		}
		else
		{
			return curr;
		}
	}
	return curr;
}


void BST::Insert(int x)
{
	if (root == nullptr)
	{
		root = new BST_node(x);
		count++;
		return;
	}
	BST_node* curr = root;
	BST_node* pcurr = NULL;
	while (curr)
	{
		pcurr = curr;
		if (x < curr->data)
		{
			curr = curr->lchild;
		}
		else if (x > curr->data)
		{
			curr = curr->rchild;
		}
		else
		{
			return;
		}
	}
	count++;
	if (x < pcurr->data)
	{
		pcurr->lchild = new BST_node(x);
	}
	else
	{
		pcurr->rchild = new BST_node(x);
	}
}

void BST::Delete(int x)
{
	if (!root)
	{
		return;
	}
	BST_node* curr = root;
	BST_node* pcurr = NULL;
	while (curr)
	{
		if (x < curr->data)
		{
			pcurr = curr;
			curr = curr->lchild;
		}
		else if (x > curr->data)
		{
			pcurr = curr;
			curr = curr->rchild;
		}
		else
		{
			if (!curr->lchild || !curr->rchild)
			{
				BST_node* t = curr->lchild ? curr->lchild : curr->rchild;
				if (t)
				{
					*curr = *t;
				}
				else
				{
					if (curr == root)
					{
						root = NULL;
					}
					else if (curr = pcurr->lchild)
					{
						pcurr->lchild = NULL;
					}
					else
					{
						pcurr->rchild = NULL;
					}
					delete curr;
				}
				delete t;
				count--;
				break;
			}
			else
			{
				BST_node* t = Min(curr->rchild);
				curr->data = t->data;
				x = t->data;
				curr = curr->rchild;
			}
		}
	}

}
void BST::bfs()
{
	int judge = 1;//�Ƿ���ȫ
	BST_node* curr;
	queue<BST_node*> a;
	vector<int> b(20, -1);//�洢����������
	int i = 0;
	a.push(root);
	int k = 0;//�Ƿ���ֹ��պ���
	while (!a.empty())
	{
		curr = a.front();
		a.pop();
		b[i++] = curr->data;
		if (curr->lchild)
		{
			a.push(curr->lchild);
			if (k == 1)
			{
				judge = 0;
			}
		}
		else
		{
			k = 1;
		}
		if (curr->rchild)
		{
			a.push(curr->rchild);
			if (k == 1)
			{
				judge = 0;
			}
		}
		else
		{
			k = 1;
		}
	}
	for (int j = 0; j < i - 1; j++)
	{
		cout << b[j] << " ";
	}
	cout << b[i - 1] << endl;
	if (judge) cout << "Yes";
	else cout << "No";
}

void BST::preorder(BST_node* x)
{
	if (x == NULL)
	{
		return;
	}
	stack<BST_node*> a;
	a.push(x);
	while (!a.empty())
	{
		BST_node* temp = a.top();
		a.pop();
		cout << temp->data << " ";
		if (temp->rchild)
		{
			a.push(temp->rchild);
		}
		if (temp->lchild)
		{
			a.push(temp->lchild);
		}
	}
}

void BST::inorder(BST_node* x)
{
	stack<BST_node*> a;
	BST_node* curr = x;
	while (curr || !a.empty())
	{
		while (curr)
		{
			a.push(curr);
			curr = curr->lchild;
		}
		curr = a.top();
		a.pop();
		cout << curr->data << " ";
		curr = curr->rchild;
	}
}

void BST::order(int x)
{
	if (x == 0)
	{
		bfs();
	}
	if (x == 1)
	{
		preorder(root);
	}
	if (x == 2)
	{
		inorder(root);
	}
}