#pragma once

class AVLnode
{
public:
	AVLnode* lchild;
	AVLnode* rchild;
	int data;
	AVLnode(int x);
};

class AVL {
public:
	AVLnode* root;
	int count; // Ԫ�ظ���
	AVL();
	AVL(AVLnode* x);

	int height(AVLnode* x);
	AVLnode* Insert(int x, AVLnode*& r);
	AVLnode* Balance(AVLnode*& x);
	void Delete(int x, AVLnode*& r);
	void bfs();
	AVLnode* L(AVLnode* x);
	AVLnode* R(AVLnode* x);
	void order(int x);
	void preorder(AVLnode* x);
	void inorder(AVLnode* x);
	AVLnode* Min(AVLnode* x);
	AVLnode* search(int x, AVLnode* r);
};


