#include<iostream>
#include"RBT.h"
using namespace std;


node::node(int k = -1, bool c = 0, int v = -1)//Ĭ�Ϻ�
{
	color = c;
	key = k;
	value = v;
	lchild = rchild = parent = NULL;
}


RBT::RBT()
{
	count = 0;
	root = NULL;
}

RBT::RBT(node* x)
{
	count = 1;
	root = x;
}

void RBT::preorder()
{
	order(root);
}

void RBT::order(node* x)
{
	if (!x)
	{
		return;
	}

	cout << x->key << "(";
	if (x->color)
	{
		cout << "B";
	}
	else
	{
		cout << "R";
	}
	cout << ") ";
	order(x->lchild);
	order(x->rchild);
}

int RBT::Max()
{
	node* curr = root;
	while (curr->rchild)
	{
		curr = curr->rchild;
	}
	return curr->key;
}

node* RBT::Max(node* x)
{
	node* curr = x;
	while (curr->rchild)
	{
		curr = curr->rchild;
	}
	return curr;
}

int RBT::Min()
{
	node* curr = root;
	while (curr->lchild)
	{
		curr = curr->lchild;
	}
	return curr->key;
}

node* RBT::Min(node* x)
{
	node* curr = x;
	while (curr->lchild)
	{
		curr = curr->lchild;
	}
	return curr;
}

node* RBT::search(int x, node* r)
{
	node* curr = r;
	while (curr)
	{
		if (curr->key > x)
		{
			curr = curr->lchild;
			continue;
		}
		if (curr->key < x)
		{
			curr = curr->rchild;
			continue;
		}
		if (curr->key == x)
		{
			return curr;
		}
	}
	return curr;
}

void RBT::L(node* x)
{
	node* pcurr = x;
	node* gpcurr = x->parent;
	node* curr = x->rchild;
	if (gpcurr)
	{
		if (x == gpcurr->lchild)
		{
			gpcurr->lchild = curr;
		}
		else
		{
			gpcurr->rchild = curr;
		}
	}
	else
	{
		root = curr;
	}
	curr->parent = gpcurr;

	pcurr->rchild = curr->lchild;
	if (curr->lchild)
	{
		curr->lchild->parent = pcurr;
	}

	curr->lchild = pcurr;
	pcurr->parent = curr;
}

void RBT::R(node* x)
{
	node* pcurr = x;
	node* gpcurr = x->parent;
	node* curr = x->lchild;
	if (gpcurr)
	{
		if (x == gpcurr->lchild)
		{
			gpcurr->lchild = curr;
		}
		else
		{
			gpcurr->rchild = curr;
		}
	}
	else
	{
		root = curr;
	}
	curr->parent = gpcurr;

	pcurr->lchild = curr->rchild;
	if (curr->rchild)
	{
		curr->rchild->parent = pcurr;
	}

	curr->rchild = pcurr;
	pcurr->parent = curr;
}

void RBT::Insert(int x)
{
	if (count == 0)
	{
		node* t = new node(x, 1);
		root = t;
		count++;
		return;
	}
	node* curr = root;
	node* pcurr = NULL;
	int lr = 0;
	while (curr)
	{
		pcurr = curr;
		if (x == curr->key)
		{
			return;
		}
		if (x < curr->key)
		{
			curr = curr->lchild;
			lr = 0;
		}
		else
		{
			curr = curr->rchild;
			lr = 1;
		}
	}
	node* t = new node(x);
	if (lr)
	{
		pcurr->rchild = t;
		t->parent = pcurr;
	}
	else
	{
		pcurr->lchild = t;
		t->parent = pcurr;
	}
	count++;
	curr = t;
	while (pcurr && pcurr->color == 0)
	{
		node* gpcurr = pcurr->parent;
		if (pcurr == gpcurr->lchild)
		{
			node* uncle = gpcurr->rchild;
			if (uncle && uncle->color == 0)//���壬�常ү��ɫ��ү���½ڵ�
			{
				pcurr->color = uncle->color = 1;
				gpcurr->color = 0;
				curr = gpcurr;
				pcurr = curr->parent;
				continue;
			}
			else//����
			{
				if (curr == pcurr->lchild)//LL
				{
					R(gpcurr);
					gpcurr->color = 0;
					pcurr->color = 1;
					break;
				}
				else//LR
				{
					L(pcurr);
					R(gpcurr);
					gpcurr->color = 0;
					curr->color = 1;
					break;
				}
			}
		}
		else
		{
			node* uncle = gpcurr->lchild;
			if (uncle && uncle->color == 0)//���壬�常ү��ɫ��ү���½ڵ�
			{
				pcurr->color = uncle->color = 1;
				gpcurr->color = 0;
				curr = gpcurr;
				pcurr = curr->parent;
				continue;
			}
			else//����
			{
				if (curr == pcurr->rchild)//RR
				{
					L(gpcurr);
					gpcurr->color = 0;
					pcurr->color = 1;
					break;
				}
				else//RL
				{
					R(pcurr);
					L(gpcurr);
					gpcurr->color = 0;
					curr->color = 1;
					break;
				}
			}
		}
	}
	root->color = 1;
}

void RBT::Delete(int x, node* r)
{
	node* curr = search(x, r);
	if (curr == NULL)
	{
		//cout << "NO FOUND" << endl;
		return;
	}
	count--;

	//������
	if (curr->lchild && curr->rchild)//���Ҷ���
	{
		node* temp = Min(curr->rchild);
		curr->key = temp->key;//��̴���
		curr = temp;
	}
	node* pcurr = curr->parent;
	int k = -1;//����0����1
	if (pcurr)
	{
		if (pcurr->lchild == curr)//�������ֵ�
		{
			k = 0;
		}
		else//�������ֵ�
		{
			k = 1;
		}
	}
	int currcolor = curr->color;
	if (curr->lchild && !curr->rchild)//��������
	{
		if (pcurr)
		{
			if (k)
			{
				pcurr->rchild = curr->lchild;
			}
			else
			{
				pcurr->lchild = curr->lchild;
			}
		}
		else
		{
			root = curr->lchild;
		}
		curr->lchild->parent = pcurr;
		curr->lchild->color = 1;
	}
	else if (!curr->lchild && curr->rchild)//��������
	{
		if (pcurr)
		{
			if (k)
			{
				pcurr->rchild = curr->rchild;
			}
			else
			{
				pcurr->lchild = curr->rchild;
			}
		}
		else
		{
			root = curr->rchild;
		}
		curr->rchild->parent = pcurr;
		curr->rchild->color = 1;
	}
	else //û������
	{
		if (pcurr)
		{
			if (k)
			{
				pcurr->rchild = NULL;
			}
			else
			{
				pcurr->lchild = NULL;
			}
		}
		else
		{
			root = NULL;
		}
	}

	//ɾ���ڵ��Ǻ�ɫ
	if (currcolor && curr->parent)
	{
		Deletebalance(curr, k);
	}

	delete curr;
	if (root)
	{
		root->color = 1;
	}
}

void RBT::Deletebalance(node* x, int k)
{
	node* curr = x;
	node* pcurr = curr->parent;
	node* bro = NULL;
	if (curr->lchild || curr->rchild)
	{
		return;
	}
	if (pcurr)
	{
		if (k)
			bro = pcurr->lchild;
		else
			bro = pcurr->rchild;
	}
	else
	{
		return;
	}
	if (!bro)
	{
		return;
	}
	if (bro->color == 1)//�ֵ��Ǻ�ɫ
	{
		if (!bro->lchild && !bro->rchild)
		{
			bro->color = 0;
			if (pcurr->color == 1 && pcurr->parent)
			{
				if (pcurr == pcurr->parent->lchild)
				{
					Deletebalance(pcurr, 0);
				}
				else
				{
					Deletebalance(pcurr, 1);
				}
			}
			else
			{
				pcurr->color = 1;
				return;
			}
		}
		else if (k == 1)//���ֵ�
		{
			if (bro->lchild && bro->lchild->color == 0)//LL
			{
				bro->lchild->color = 1;
				pcurr->color = 1;
				R(pcurr);
			}
			else if (bro->rchild && bro->rchild->color == 0)//LR
			{
				bro->rchild->color = pcurr->color;
				pcurr->color = 1;
				L(bro);
				R(pcurr);
			}
		}
		else//���ֵ�
		{
			if (bro->rchild && bro->rchild->color == 0)//RR
			{
				bro->rchild->color = 1;
				pcurr->color = 1;
				L(pcurr);
			}
			else if (bro->lchild && bro->lchild->color == 0)//RL
			{
				bro->lchild->color = pcurr->color;
				pcurr->color = 1;
				R(bro);
				L(pcurr);
			}
		}
	}
	else//�ֵ��Ǻ�ɫ
	{
		bro->color = 1;
		pcurr->color = 0;
		if (k == 1)
		{
			R(pcurr);
		}
		else
		{
			L(pcurr);
		}
		Deletebalance(curr, k);
	}
	if (root)
	{
		root->color = 1;
	}
}